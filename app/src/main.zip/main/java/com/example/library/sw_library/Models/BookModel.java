package com.example.library.sw_library.Models;

/*
model for book
 */

public class BookModel {

    private int bookID ;
    private String name, authorName;
    private int categoryID;

}
